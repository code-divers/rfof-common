# rfof-common
A common library for rfof projects.

## How to use it

1. Clone from github
2. Install npm module
3. Build project.

```
git clone git@github.com:code-divers/rfof-common.git
cd rfof-common
npm install
npm run build
```
